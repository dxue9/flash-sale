package com.wangzehao.flashsale;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlashSaleApplicationTests {

    @Test
    void contextLoads() {
    }

}
